package bot;

import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.MessageChannel;
import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import javax.security.auth.login.LoginException;

public class Main extends ListenerAdapter {

    private static final String TOKEN = "";

    public static void main(String[] args) throws LoginException {
        // Создаем базу данных
        database.DatabaseManager.initialize();

        // Запускаем JDA
        JDA jda = JDABuilder.createDefault(TOKEN).build();
        jda.addEventListener(new Main());
        System.out.println("Дискорд бот запущен!");
    }

    @Override
    public void onGuildMessageReceived(GuildMessageReceivedEvent event) {
        // игнорируем сообщения ботов
        if (event.getAuthor().isBot()) return;

        String message = event.getMessage().getContentRaw();
        long discordId = event.getAuthor().getIdLong();
        MessageChannel channel = event.getChannel();

        // Обработка команд
        try {
            if (message.startsWith("/addclone")) {
                commands.AddCloneCommand.execute(event, message, discordId);
            } else if (message.equals("/listclone")) {
                String response = commands.ListCloneCommand.execute();
                channel.sendMessage(response).queue();
            } else if (message.equals("/delclone")) {
                commands.DelCloneCommand.execute(discordId);
                channel.sendMessage("Ваш аккаунт удален из базы.").queue();
            }
        } catch (Exception e) {
            e.printStackTrace();
            channel.sendMessage("Произошла ошибка при выполнении команды.").queue();
        }
    }
}