package database;

import java.sql.*;

public class DatabaseManager {
    private static final String DB_URL = "jdbc:sqlite:users.db";

    public static void initialize() {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS users (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "name TEXT NOT NULL," +
                    "idn TEXT NOT NULL," +
                    "formation TEXT," +
                    "rank TEXT," +
                    "discord_id TEXT UNIQUE," +
                    "email TEXT" +
                    ")";
            stmt.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static boolean addClone(String name, String idn, String formation, String rank, String email, String discordId) {
        String sql = "INSERT INTO users (name, idn, formation, rank, discord_id, email) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, idn);
            pstmt.setString(3, formation);
            pstmt.setString(4, rank);
            pstmt.setString(5, discordId);
            pstmt.setString(6, email);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            if (e.getMessage().contains("UNIQUE constraint failed")) {
                return false;
            }
            e.printStackTrace();
            return false;
        }
    }

    public static String getAllClone() {
        StringBuilder sb = new StringBuilder();
        String sql = "SELECT * FROM users";

        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                sb.append("ID: ").append(rs.getInt("id"))
                        .append(", Имя: ").append(rs.getString("name"))
                        .append(", IDN: ").append(rs.getString("idn"))
                        .append(", Формирование: ").append(rs.getString("formation"))
                        .append(", Звание: ").append(rs.getString("rank"))
                        .append(", Discord ID: ").append(rs.getString("discord_id"))
                        .append(", Email: ").append(rs.getString("email"))
                        .append("\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "Ошибка при получении данных.";
        }
        return sb.toString();
    }

    public static void deleteClone(String discordId) {
        String sql = "DELETE FROM users WHERE discord_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, discordId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}