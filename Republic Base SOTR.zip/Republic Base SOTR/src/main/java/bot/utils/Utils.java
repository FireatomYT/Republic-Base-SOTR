package utils;

public class Utils {
    /**
     * Проверяет, начинается ли сообщение с командой, игнорируя регистр.
     */
    public static boolean isCommand(String message, String command) {
        return message.toLowerCase().startsWith(command.toLowerCase());
    }
}