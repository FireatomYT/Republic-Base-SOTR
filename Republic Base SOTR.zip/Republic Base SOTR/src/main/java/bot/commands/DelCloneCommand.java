package commands;

import database.DatabaseManager;

public class DelCloneCommand {
    public static void execute(long discordId) {
        DatabaseManager.deleteClone(String.valueOf(discordId));
    }
}