package commands;

import database.DatabaseManager;

public class ListCloneCommand {
    public static String execute() {
        return DatabaseManager.getAllClone();
    }
}