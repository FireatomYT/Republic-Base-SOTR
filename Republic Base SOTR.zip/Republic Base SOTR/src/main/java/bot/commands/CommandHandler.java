package commands;

import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent;

public class CommandHandler {
    public static void handleCommand(GuildMessageReceivedEvent event, String message, long discordId) {
        if (message.startsWith("/addclone")) {
            AddCloneCommand.execute(event, message, discordId);
        } else if (message.equals("/listclone")) {
            String response = ListUsersCommand.execute();
            event.getChannel().sendMessage(response).queue();
        } else if (message.equals("/delclone")) {
            DelUserCommand.execute(discordId);
            event.getChannel().sendMessage("Ваш аккаунт удален из базы.").queue();
        }
        // можно добавить больше команд
    }
}