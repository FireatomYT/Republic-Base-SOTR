package commands;

import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent;
import database.DatabaseManager;

public class AddCloneCommand {
    public static void execute(GuildMessageReceivedEvent event, String message, long discordId) {
        String[] parts = message.split(" ");
        if (parts.length < 6) {
            event.getChannel().sendMessage("Используйте: /addclone Имя IDN Формирование Звание Email").queue();
            return;
        }

        String name = parts[1];
        String idn = parts[2];
        String formation = parts[3];
        String rank = parts[4];
        String email = parts[5];

        boolean success = DatabaseManager.addUser(name, idn, formation, rank, email, String.valueOf(discordId));
        if (success) {
            event.getChannel().sendMessage("Пользователь добавлен!").queue();
        } else {
            event.getChannel().sendMessage("Ошибка: возможно такой Discord ID уже есть.").queue();
        }
    }
}